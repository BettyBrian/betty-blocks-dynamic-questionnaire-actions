import { default as expression_1_0 } from './functions/expression/1.0';
import { default as randomHex_1_0 } from './functions/randomHex/1.0';
import { default as sendMail_1_0 } from './functions/sendMail/1.0';

const fn = {
  "expression 1.0": expression_1_0,
  "randomHex 1.0": randomHex_1_0,
  "sendMail 1.0": sendMail_1_0,
};

export default fn;
